#include <Arduino.h>
#include <TimerOne.h>
#include <Adafruit_ADS1015.h>
Adafruit_ADS1115 ads(0x48);
#include <Adafruit_ST7735.h> // Hardware-specific library
#include <Adafruit_Sensor.h>
#include <SPI.h>
#include <Wire.h>
//-----------------
#define sclk 13
#define mosi 11
#define cs   10
#define dc   9
#define rst  8  
//-----------------------------------------
const char mac_addr[]="0013A20041C8AD7A";
const char STX=0x02;
const char ETX=0x03;
const char CR=0x13;
const char LF=0x10;
//---------------------------------------------
void(*resetFunc)(void)=0;
//---------------------------------------------
#define    MPU9250_ADDRESS_1            0x68
#define    MAG_ADDRESS_1                0x0C
#define    MPU9250_ADDRESS_2            0x69
#define    MAG_ADDRESS_2                0x0C
#define    GYRO_FULL_SCALE_250_DPS    0x00  
#define    GYRO_FULL_SCALE_500_DPS    0x08
#define    GYRO_FULL_SCALE_1000_DPS   0x10
#define    GYRO_FULL_SCALE_2000_DPS   0x18
#define    ACC_FULL_SCALE_2_G        0x00  
#define    ACC_FULL_SCALE_4_G        0x08
#define    ACC_FULL_SCALE_8_G        0x10
#define    ACC_FULL_SCALE_16_G       0x18
//---------------------------------------------
float ax,ay,az;
float ax_1,ay_1,az_1;
float X,Y,Z,GX,GY,GZ,GX_Top,GY_Top,GZ_Top;
float X_1,Y_1,Z_1,GX_1,GY_1,GZ_1,GX_Top_1,GY_Top_1,GZ_Top_1;
float X_Zero;
float Y_Zero;
float Z_Zero;
float X_Zero_1;
float Y_Zero_1;
float Z_Zero_1;
long int cpt=0;
long int ti;
int index=0;
int index_1=0;

Adafruit_ST7735 tft = Adafruit_ST7735(cs, dc, rst);
//---------------------------------------------
void I2Cread(uint8_t Address, uint8_t Register, uint8_t Nbytes, uint8_t* Data)
{
  Wire.beginTransmission(Address);
  Wire.write(Register);
  Wire.endTransmission();
  Wire.requestFrom(Address, Nbytes); 
  uint8_t index=0;
  while (Wire.available())
    Data[index++]=Wire.read();
}
//---------------------------------------------------------------------
void I2CwriteByte(uint8_t Address, uint8_t Register, uint8_t Data)
{
  Wire.beginTransmission(Address);
  Wire.write(Register);
  Wire.write(Data);
  Wire.endTransmission();
}
//---------------------------------------------------------------------
void setup()
{
  Wire.begin();
  Serial.begin(9600);
  tft.initR(INITR_GREENTAB);
  tft.fillScreen(ST7735_BLACK);
  sc1();
  I2CwriteByte(MPU9250_ADDRESS_1,29,0x06);
  I2CwriteByte(MPU9250_ADDRESS_1,26,0x06);
  I2CwriteByte(MPU9250_ADDRESS_1,27,GYRO_FULL_SCALE_1000_DPS);
  I2CwriteByte(MPU9250_ADDRESS_1,28,ACC_FULL_SCALE_4_G);
  I2CwriteByte(MPU9250_ADDRESS_1,0x37,0x02);
  I2CwriteByte(MAG_ADDRESS_1,0x0A,0x16);
  
  I2CwriteByte(MPU9250_ADDRESS_2,29,0x06);
  I2CwriteByte(MPU9250_ADDRESS_2,26,0x06);
  I2CwriteByte(MPU9250_ADDRESS_2,27,GYRO_FULL_SCALE_1000_DPS);
  I2CwriteByte(MPU9250_ADDRESS_2,28,ACC_FULL_SCALE_4_G);
  I2CwriteByte(MPU9250_ADDRESS_2,0x37,0x02);
  I2CwriteByte(MAG_ADDRESS_2,0x0A,0x16);
}

//**************************************************
void loop()
{
  //-------------------------------
  static unsigned long Boot_Timer = millis(); // static unsigned long OledTimer=millis();
  if (millis() - Boot_Timer >= 7200000)
  {
    Boot_Timer = millis();  
    resetFunc();
  }
  //---------------------------------------------
  uint8_t Buf[14];
  I2Cread(MPU9250_ADDRESS_1,0x3B,14,Buf);
  int16_t ax=-(Buf[0]<<8 | Buf[1]);
  int16_t ay=-(Buf[2]<<8 | Buf[3]);
  int16_t az=Buf[4]<<8 | Buf[5];
  
  int16_t gx=-(Buf[8]<<8 | Buf[9]);
  int16_t gy=-(Buf[10]<<8 | Buf[11]);
  int16_t gz=Buf[12]<<8 | Buf[13];
  
  X=ax;
  Y=ay;
  Z=az;
  
  GX=X/2000;
  GY=Y/2000;
  GZ=Z/2000;
  
  
  uint8_t Buf_1[14];
  I2Cread(MPU9250_ADDRESS_2,0x3B,14,Buf_1);
  int16_t ax_1=-(Buf_1[0]<<8 | Buf_1[1]);
  int16_t ay_1=-(Buf_1[2]<<8 | Buf_1[3]);
  int16_t az_1=Buf_1[4]<<8 | Buf_1[5];
  
  int16_t gx_1=-(Buf_1[8]<<8 | Buf_1[9]);
  int16_t gy_1=-(Buf_1[10]<<8 | Buf_1[11]);
  int16_t gz_1=Buf_1[12]<<8 | Buf_1[13];
  
  X_1=ax_1;
  Y_1=ay_1;
  Z_1=az_1;
  
  GX_1=X_1/2000;
  GY_1=Y_1/2000;
  GZ_1=Z_1/2000;

  if (abs(GX)>=abs(GX_Top)){
     GX_Top=(GX);
  }
  if (abs(GY)>=abs(GY_Top)){
     GY_Top=(GY);
  }
  if (abs(GZ)>=abs(GZ_Top)){
     GZ_Top=(GZ);
  }

  if (abs(GX_1)>=abs(GX_Top_1)){
     GX_Top_1=(GX_1);
  }
  if (abs(GY_1)>=abs(GY_Top_1)){
     GY_Top_1=(GY_1);
  }
  if (abs(GZ_1)>=abs(GZ_Top_1)){
     GZ_Top_1=(GZ_1);
  }
//---------------------------------
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,5,63,24,ST7735_BLACK);
    tft.setCursor(63,5); // x.y
    tft.setTextColor(ST7735_BLUE);
    tft.print(GX,2);  
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,30,63,24,ST7735_BLACK);
    tft.setCursor(63,30 ); // x.y
    tft.setTextColor(ST7735_BLUE);
    tft.print(GY,2); 
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,55,63,24,ST7735_BLACK);
    tft.setCursor(63,55 ); // x.y
    tft.setTextColor(ST7735_BLUE);
    tft.print(GZ,2); 
    
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,85,63,24,ST7735_BLACK);
    tft.setCursor(63,85 ); // x.y
    tft.setTextColor(ST7735_GREEN);
    tft.print(GX_1,2);
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,110,63,24,ST7735_BLACK);
    tft.setCursor(63,110 ); // x.y
    tft.setTextColor(ST7735_GREEN);
    tft.print(GY_1,1); 
    tft.setTextSize(2); // 　自型大小
    tft.fillRect(63,135,63,24,ST7735_BLACK);
    tft.setCursor(63,135 ); // x.y
    tft.setTextColor(ST7735_GREEN);
    tft.print(GZ_1,1);
     delay(25); 
   //-------------------------   
  index++;  
  if (index>=40){
  Serial.print(STX);
  Serial.print(mac_addr);
  Serial.print(",");
  Serial.print("6");
  Serial.print(",");
  Serial.print (GX_Top,3); 
  Serial.print (",");
  Serial.print (GY_Top,3);
  Serial.print (",");
  Serial.print (GZ_Top,3);
  Serial.print(",");
  Serial.print (GX_Top_1,3); 
  Serial.print (",");
  Serial.print (GY_Top_1,3);
  Serial.print (",");
  Serial.print (GZ_Top_1,3);
  Serial.print(ETX);
  Serial.print(CR);
  Serial.println(LF);   
  GX_Top=0;
  GY_Top=0;
  GZ_Top=0; 
  GX_Top_1=0;
  GY_Top_1=0;
  GZ_Top_1=0; 
  index=0; 
  }
}

void sc1(void)
  {
    tft.drawRect(0,0,127,159,ST7735_GREEN);
  //------------------Particle TFT Display--------------------------------------------//      
    tft.setTextSize(2); // 　自型大小
    tft.setCursor(6,5 ); // x.y
    tft.setTextColor(ST7735_CYAN);
    tft.print("GX_1:"); 
    tft.setCursor(6,30 ); // x.y
    tft.setTextColor(ST7735_CYAN);
    tft.print("GY_1:"); 
    tft.setCursor(6,55 ); // x.y
    tft.setTextColor(ST7735_CYAN);
    tft.print("GZ_1:"); 
    //---------------------------------------
    tft.drawLine(1,80,126,80,ST7735_GREEN);
   //-----------------------------------   
    tft.setTextSize(2); // 　自型大小
    tft.setCursor(6,85 ); // x.y
    tft.setTextColor(ST7735_YELLOW);
    tft.print("GX_2:"); 
    tft.setCursor(6,110 ); // x.y
    tft.setTextColor(ST7735_YELLOW);
    tft.print("GY_2:"); 
    tft.setCursor(6,135 ); // x.y
    tft.setTextColor(ST7735_YELLOW);
    tft.print("GZ_2:"); 
    //---------------------------------------

}






