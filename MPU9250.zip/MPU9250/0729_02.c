// 1 nano with 2 MPU9250
#include "MPU9250.h"

MPU9250 IMU1(SPI,10);
MPU9250 IMU2(SPI,9);

int status1;
float ax1_before,ay1_before,az1_before,ax1,ay1,az1;
float gx1,gy1,gz1;
float mx1_before,my1_before,mz1_before,mx1,my1,mz1;
float temp1;
float roll1_before,pitch1_before,yaw1_before,roll1,pitch1,yaw1;

int status2;
float ax2_before,ay2_before,az2_before,ax2,ay2,az2;
float gx2,gy2,gz2;
float mx2_before,my2_before,mz2_before,mx2,my2,mz2;
float temp2;
float roll2_before,pitch2_before,yaw2_before,roll2,pitch2,yaw2;

void setup() {

  Serial.begin(115200);
  while(!Serial1){}

  status1 = IMU1.begin();
 /* if (status1 < 0){
    Serial.println("IMU1 initialization unsuccessful");
    Serial.println("Check IMU1 wiring or try cycling power");
    Serial.print("Status1: ");
    Serial.println(status1);
    while (1) {}
  }*/
  // 加速度 (before)
  IMU1.readSensor();
  ax1_before = IMU1.getAccelX_mss();
  ay1_before = IMU1.getAccelY_mss();
  az1_before = IMU1.getAccelZ_mss() + 9.8;
  // 磁場 magnetic (before)
  mx1_before = IMU1.getMagX_uT();
  my1_before = IMU1.getMagY_uT();
  mz1_before = IMU1.getMagZ_uT();
  // 旋轉角度(before)
  roll1_before = atan2(-ax1_before,(sqrt((ay1_before*ay1_before)+(az1_before*az1_before))));
  roll1_before = roll1_before*57.3;
  pitch1_before = atan2(ay1_before,(sqrt((ax1_before*ax1_before)+(az1_before*az1_before))));
  pitch1_before = pitch1_before*57.3;
  float Yh1_before = (my1_before*cos(roll1_before))-(mz1_before*sin(roll1_before));
  float Xh1_before = (mx1_before*cos(pitch1_before))+(my1_before*sin(roll1_before)*sin(pitch1_before))+(mz1_before*cos(roll1_before)*sin(pitch1_before));
  yaw1_before = atan2(Yh1_before,Xh1_before);
  yaw1_before = yaw1_before*57.3;
  
  status2 = IMU2.begin();
 /* if (status2 < 0){
    Serial.println("IMU2 initialization unsuccessful");
    Serial.println("Check IMU2 wiring or try cycling power");
    Serial.print("Status2: ");
    Serial.println(status2);
    while (1) {}
  }*/
  // 加速度 (before)
  IMU2.readSensor();
  ax2_before = IMU2.getAccelX_mss();
  ay2_before = IMU2.getAccelY_mss();
  az2_before = IMU2.getAccelZ_mss() + 9.8;
  // 磁場 magnetic (before)
  mx2_before = IMU2.getMagX_uT();
  my2_before = IMU2.getMagY_uT();
  mz2_before = IMU2.getMagZ_uT();
  // 旋轉角度(before)
  roll2_before = atan2(-ax2_before,(sqrt((ay2_before*ay2_before)+(az2_before*az2_before))));
  roll2_before = roll2_before*57.3;
  pitch2_before = atan2(ay2_before,(sqrt((ax2_before*ax2_before)+(az2_before*az2_before))));
  pitch2_before = pitch2_before*57.3;
  float Yh2_before = (my2_before*cos(roll2_before))-(mz2_before*sin(roll2_before));
  float Xh2_before = (mx2_before*cos(pitch2_before))+(my2_before*sin(roll2_before)*sin(pitch2_before))+(mz2_before*cos(roll2_before)*sin(pitch2_before));
  yaw2_before = atan2(Yh2_before,Xh2_before);
  yaw2_before = yaw2_before*57.3;
}


void loop() {
  IMU1.readSensor();
  // 加速度1 accel
  ax1 = IMU1.getAccelX_mss() - ax1_before;
  ay1 = IMU1.getAccelY_mss() - ay1_before;
  az1 = IMU1.getAccelZ_mss() - az1_before + 9.8;
  // 陀螺儀1 gyro
  gx1 = IMU1.getGyroX_rads();
  gy1 = IMU1.getGyroY_rads();
  gz1 = IMU1.getGyroZ_rads();
  // 磁場1 magnetic
  mx1 = IMU1.getMagX_uT();
  my1 = IMU1.getMagY_uT();
  mz1 = IMU1.getMagZ_uT();
  //  溫度1
  temp1 = IMU1.getTemperature_C();
  // roll1 
  roll1 = atan2(-ax1,(sqrt((ay1*ay1)+(az1*az1))));
  roll1 = roll1*57.3;
  roll1 = roll1 - roll1_before;
  // pitch1
  pitch1 = atan2(ay1,(sqrt((ax1*ax1)+(az1*az1))));
  pitch1 = pitch1*57.3 - pitch1_before;
  // yaw1
  float Yh1 = (my1*cos(roll1))-(mz1*sin(roll1));
  float Xh1 = (mx1*cos(pitch1))+(my1*sin(roll1)*sin(pitch1))+(mz1*cos(roll1)*sin(pitch1));
  yaw1 = atan2(Yh1,Xh1);
  yaw1 = yaw1*57.3 - yaw1_before;
  
  
  IMU2.readSensor();
  // 加速度2 accel
  ax2 = IMU2.getAccelX_mss() - ax2_before;
  ay2 = IMU2.getAccelY_mss() - ay2_before;
  az2 = IMU2.getAccelZ_mss() - az2_before + 9.8;
  // 陀螺儀2 gyro
  gx2 = IMU2.getGyroX_rads();
  gy2 = IMU2.getGyroY_rads();
  gz2 = IMU2.getGyroZ_rads();
  // 磁場2 magnetic
  mx2 = IMU2.getMagX_uT();
  my2 = IMU2.getMagY_uT();
  mz2 = IMU2.getMagZ_uT();
  //  溫度2
  temp2 = IMU2.getTemperature_C();
  // roll2 
  roll2 = atan2(-ax2,(sqrt((ay2*ay2)+(az2*az2))));
  roll2 = roll2*57.3;
  roll2 = roll2 - roll2_before;
  // pitch2
  pitch2 = atan2(ay2,(sqrt((ax2*ax2)+(az2*az2))));
  pitch2 = pitch2*57.3 - pitch2_before;
  // yaw2
  float Yh2 = (my2*cos(roll2))-(mz2*sin(roll2));
  float Xh2 = (mx2*cos(pitch2))+(my2*sin(roll2)*sin(pitch2))+(mz2*cos(roll1)*sin(pitch1));
  yaw1 = atan2(Yh1,Xh1);
  yaw1 = yaw1*57.3 - yaw1_before;
  
  Serial.print("MPU1加速度: ");
  Serial.print(ax,6);
  Serial.print("\t");
  Serial.print(ay,6);
  Serial.print("\t");
  Serial.println(az,6);
  
  Serial.print("MPU1陀螺儀: ");
  Serial.print(gx1,6);
  Serial.print("\t");
  Serial.print(gy1,6);
  Serial.print("\t");
  Serial.println(gz1,6);
  
  Serial.print("MPU1磁場: ");
  Serial.print(mx1,6);
  Serial.print("\t");
  Serial.print(my1,6);
  Serial.print("\t");
  Serial.println(mz1,6);
  
  Serial.print("MPU1溫度: ");
  Serial.println(temp1);
  
  Serial.print("MPU1前後旋轉角度: ");
  Serial.println(pitch1);
  
  Serial.print("MPU1左右旋轉角度: ");
  Serial.println(roll1);
  
  Serial.print("MPU1水平旋轉");
  Serial.println(yaw1);
  delay(5000);
  }
