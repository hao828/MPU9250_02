﻿#include "MPU9250.h"
#include <Arduino.h>
#include <SoftwareSerial.h>
#include <stdio.h>

MPU9250 IMU(SPI,10);
MPU9250 IMU1(SPI,9);

int status;
float ax_before,ay_before,az_before,ax,ay,az;
float gx,gy,gz;
float mx,my,mz;
float temp;
float roll,pitch,yaw;

int status1;
float ax1_before,ay1_before,az1_before,ax1,ay1,az1;
float gx1,gy1,gz1;
float mx1,my1,mz1;
float temp1;
float roll1,pitch1,yaw1;

const char mac_addr[]="0013A20041D1E4C2";
const char STX=0x02;
const char ETX=0x03;
const char CR=0x13;
const char LF=0x10;

void setup() {

  Serial.begin(9600);
  while(!Serial){}

  status = IMU.begin();
  /*if (status < 0){
    Serial.println("IMU initialization unsuccessful");
    Serial.println("Check IMU wiring or try cycling power");
    Serial.print("Status: ");
    Serial.println(status);
    // while (1) {}
  }*/
  // 加速度 (before)
  IMU.readSensor();
  ax_before = IMU.getAccelX_mss();
  ay_before = IMU.getAccelY_mss();
  az_before = IMU.getAccelZ_mss() + 9.8;

  // 加速度1 (before)
  IMU1.readSensor();
  ax1_before = IMU1.getAccelX_mss();
  ay1_before = IMU1.getAccelY_mss();
  az1_before = IMU1.getAccelZ_mss() + 9.8;
}


void loop() {
  IMU.readSensor();
  // 加速度 accel
  ax = IMU.getAccelX_mss() - ax_before;
  ay = IMU.getAccelY_mss() - ay_before;
  ay = IMU.getAccelZ_mss() - az_before + 9.8;
  // 陀螺儀 gyro
  gx = IMU.getGyroX_rads();
  gy = IMU.getGyroY_rads();
  gz = IMU.getGyroZ_rads();
  // 磁場 magnetic
  mx = IMU.getMagX_uT();
  my = IMU.getMagY_uT();
  mz = IMU.getMagZ_uT();
  //  溫度
  temp = IMU.getTemperature_C();
  // roll 
  roll = atan2(-ax,(sqrt((ay*ay)+(az*az))));
  roll = roll*57.3;
  // pitch
  pitch = atan2(ay,(sqrt((ax*ax)+(az*az))));
  pitch = pitch*57.3;
  // yaw
  float Yh = (my*cos(roll))-(mz*sin(roll));
  float Xh = (mx*cos(pitch))+(my*sin(roll)*sin(pitch))+(mz*cos(roll)*sin(pitch));
  yaw = atan2(Yh,Xh);
  yaw = yaw*57.3;

  ///// MPU9250_01 ///// 
  IMU1.readSensor();
  // 加速度 accel
  ax1 = IMU1.getAccelX_mss() - ax1_before;
  ay1 = IMU1.getAccelY_mss() - ay1_before;
  az1 = IMU1.getAccelZ_mss() - az1_before + 9.8;
  // 陀螺儀 gyro
  gx1 = IMU1.getGyroX_rads();
  gy1 = IMU1.getGyroY_rads();
  gz1 = IMU1.getGyroZ_rads();
  // 磁場 magnetic
  mx1 = IMU1.getMagX_uT();
  my1 = IMU1.getMagY_uT();
  mz1 = IMU1.getMagZ_uT();
  //  溫度
  temp1 = IMU1.getTemperature_C();
  // roll 
  roll1 = atan2(-ax1,(sqrt((ay1*ay1)+(az1*az1))));
  roll1 = roll1*57.3;
  // pitch
  pitch1 = atan2(ay1,(sqrt((ax1*ax1)+(az1*az1))));
  pitch1 = pitch1*57.3;
  // yaw
  float Yh1 = (my1*cos(roll1))-(mz1*sin(roll1));
  float Xh1 = (mx1*cos(pitch1))+(my1*sin(roll1)*sin(pitch1))+(mz1*cos(roll1)*sin(pitch1));
  yaw1 = atan2(Yh1,Xh1);
  yaw1 = yaw1*57.3;
  //Serial.print("加速度: ");
  //Serial.print(ax,6);
  //Serial.print("\t");
  //Serial.print(ay,6);
  //Serial.print("\t");
  //Serial.println(az,6);
  
  //Serial.print("陀螺儀: ");
  //Serial.print(gx,6);
  //Serial.print("\t");
  //Serial.print(gy,6);
  //Serial.print("\t");
  //Serial.println(gz,6);
  
  //Serial.print("磁場: ");
  //Serial.print(mx,6);
  //Serial.print("\t");
  //Serial.print(my,6);
  //Serial.print("\t");
  //Serial.println(mz,6);
  
  //Serial.print("溫度: ");
  //Serial.println(temp);
  
  //Serial.print("前後旋轉角度: ");
  //Serial.println(pitch);
  
  //Serial.print("左右旋轉角度: ");
  //Serial.println(roll);
  
  //Serial.print("水平旋轉");
  //Serial.println(yaw);
  //delay(5000);

  /////Data Print

	Serial.print(STX);
	Serial.print(mac_addr);
	Serial.print(",");
	Serial.print("6");
	Serial.print(",");
	Serial.print(pitch);
	Serial.print(",");
	Serial.print(roll);
	Serial.print(",");
	Serial.println(yaw);
	Serial.print(",");
	Serial.print(pitch1);
	Serial.print(",");
	Serial.print(roll1);
	Serial.print(",");
	Serial.println(yaw1);
	Serial.print(",");
	Serial.print(ETX);
	Serial.print(CR);
	Serial.println(LF);
  

}
