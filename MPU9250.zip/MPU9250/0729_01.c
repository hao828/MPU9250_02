// 1 nano with 1 MPU9250
#include "MPU9250.h"

MPU9250 IMU1(SPI,10);


int status1;
float ax1_before,ay1_before,az1_before,ax1,ay1,az1;
float gx1,gy1,gz1;
float mx1_before,my1_before,mz1_before,mx1,my1,mz1;
float temp1;
float roll1_before,pitch1_before,yaw1_before,roll1,pitch1,yaw1;
void setup() {

  Serial.begin(115200);
  while(!Serial1){}

  status1 = IMU1.begin();
 /* if (status1 < 0){
    Serial.println("IMU1 initialization unsuccessful");
    Serial.println("Check IMU1 wiring or try cycling power");
    Serial.print("Status1: ");
    Serial.println(status1);
    while (1) {}
  }*/
  // 加速度 (before)
  IMU1.readSensor();
  ax1_before = IMU1.getAccelX_mss();
  ay1_before = IMU1.getAccelY_mss();
  az1_before = IMU1.getAccelZ_mss() + 9.8;
  // 磁場 magnetic (before)
  mx1_before = IMU1.getMagX_uT();
  my1_before = IMU1.getMagY_uT();
  mz1_before = IMU1.getMagZ_uT();
  // 旋轉角度(before)
  roll1_before = atan2(-ax1_before,(sqrt((ay1_before*ay1_before)+(az1_before*az1_before))));
  roll1_before = roll1_before*57.3;
  pitch1_before = atan2(ay1_before,(sqrt((ax1_before*ax1_before)+(az1_before*az1_before))));
  pitch1_before = pitch1_before*57.3;
  float Yh1_before = (my1_before*cos(roll1_before))-(mz1_before*sin(roll1_before));
  float Xh1_before = (mx1_before*cos(pitch1_before))+(my1_before*sin(roll1_before)*sin(pitch1_before))+(mz1_before*cos(roll1_before)*sin(pitch1_before));
  yaw1_before = atan2(Yh1_before,Xh1_before);
  yaw1_before = yaw1_before*57.3;
}


void loop() {
  IMU1.readSensor();
  // 加速度1 accel
  ax1 = IMU1.getAccelX_mss() - ax_before;
  ay1 = IMU1.getAccelY_mss() - ay_before;
  az1 = IMU1.getAccelZ_mss() - az_before + 9.8;
  // 陀螺儀1 gyro
  gx1 = IMU1.getGyroX_rads();
  gy1 = IMU1.getGyroY_rads();
  gz1 = IMU1.getGyroZ_rads();
  // 磁場1 magnetic
  mx1 = IMU1.getMagX_uT();
  my1 = IMU1.getMagY_uT();
  mz1 = IMU1.getMagZ_uT();
  //  溫度1
  temp1 = IMU1.getTemperature_C();
  // roll1 
  roll1 = atan2(-ax1,(sqrt((ay1*ay1)+(az1*az1))));
  roll1 = roll1*57.3;
  roll1 = roll1 - roll1_before;
  // pitch1
  pitch1 = atan2(ay1,(sqrt((ax1*ax1)+(az1*az1))));
  pitch1 = pitch1*57.3 - pitch1_before;
  // yaw1
  float Yh1 = (my1*cos(roll1))-(mz1*sin(roll1));
  float Xh1 = (mx1*cos(pitch1))+(my1*sin(roll1)*sin(pitch1))+(mz1*cos(roll1)*sin(pitch1));
  yaw1 = atan2(Yh1,Xh1);
  yaw1 = yaw1*57.3 - yaw1_before;
  
  Serial.print("MPU1加速度: ");
  Serial.print(ax,6);
  Serial.print("\t");
  Serial.print(ay,6);
  Serial.print("\t");
  Serial.println(az,6);
  
  Serial.print("MPU1陀螺儀: ");
  Serial.print(gx1,6);
  Serial.print("\t");
  Serial.print(gy1,6);
  Serial.print("\t");
  Serial.println(gz1,6);
  
  Serial.print("MPU1磁場: ");
  Serial.print(mx1,6);
  Serial.print("\t");
  Serial.print(my1,6);
  Serial.print("\t");
  Serial.println(mz1,6);
  
  Serial.print("MPU1溫度: ");
  Serial.println(temp1);
  
  Serial.print("MPU1前後旋轉角度: ");
  Serial.println(pitch1);
  
  Serial.print("MPU1左右旋轉角度: ");
  Serial.println(roll1);
  
  Serial.print("MPU1水平旋轉");
  Serial.println(yaw1);
  delay(5000);
  }
